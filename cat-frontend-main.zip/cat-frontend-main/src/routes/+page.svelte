<script>
	import { createEventDispatcher } from 'svelte';
	import { Magnifier } from 'svelte-magnifier';

	const dispatch = createEventDispatcher();
	let resultData = null;
	let error = null;
	let isUploading = false;

	async function handleFormSubmit(event) {
		event.preventDefault();
		const formData = new FormData();
		const fileInput = document.getElementById('file-input');
		const body = document.getElementById('results-body');

		body.style.backgroundImage =
			"url('https://californiatransplants.com/wp-content/uploads/2020/03/about-general-bg.jpg')";
		body.style.backgroundSize = 'cover';
		body.style.backgroundRepeat = 'no-repeat';
		body.style.backgroundPosition = 'center center';

		if (fileInput && fileInput.files.length > 0) {
			formData.append('file', fileInput.files[0]);
		} else {
			throw new Error('No file selected');
		}

		try {
			isUploading = true;
			const response = await fetch('http://127.0.0.1:5000/upload', {
				method: 'POST',
				body: formData
			});

			if (!response.ok) {
				throw new Error(`HTTP error! status: ${response.status}`);
			}

			const data = await response.json();
			resultData = data;
			error = null;
			dispatch('result', data);
		} catch (err) {
			console.error(err);
			error = err.message;
		} finally {
			isUploading = false;
		}
	}

	function handleFileInputChange(event) {
		const fileInput = event.target;
		const file = fileInput.files[0];

		if (file) {
			const formData = new FormData();
			formData.append('file', file);
			fileInput.form.dispatchEvent(new Event('submit'));
		}
	}

	function saveToCSV(event) {
		event.preventDefault();
		if (resultData) {
			const rows = [
				['Message', resultData.message],
				['Single Plants Count', resultData.info.single_plants_count],
				['Multiple Plants Count', resultData.info.multiple_plants_count],
				['No Plants Count', resultData.info.no_plants_count],
				[
					'Viability',
					(
						((resultData.info.single_plants_count + (resultData.info.multiple_plants_count) * 2) /
							(resultData.info.num_rows * resultData.info.num_cols)) *
						100
					).toFixed(2) + '%'
				],
				['Tray Rows', resultData.info.num_rows],
				['Tray Columns', resultData.info.num_cols],
				['Tray Cell Count', resultData.info.num_rows * resultData.info.num_cols]
			];

			// add headers for the result matrix
			rows[0].push('Cell 1');
			for (let i = 0; i < resultData.info.num_cols; i++) {
				rows[0].push(`Cell ${i + 2}`);
			}

			// add data for the result matrix
			for (let i = 0; i < resultData.info.num_rows; i++) {
				const row = [`Row ${i + 1}`];
				row.push(''); // empty first column
				for (let j = 0; j < resultData.info.num_cols; j++) {
					row.push(resultData.info.result_matrix[i][j]);
				}
				rows.push(row);
			}

			// convert the rows into a CSV string
			const csvString = rows.map((row) => row.join(',')).join('\n');

			// create a blob from the CSV string
			const blob = new Blob([csvString], { type: 'text/csv' });

			// create a download link for the CSV file and trigger the download
			const downloadLink = document.createElement('a');
			downloadLink.download = 'result.csv';
			downloadLink.href = URL.createObjectURL(blob);
			downloadLink.click();
			URL.revokeObjectURL(downloadLink.href);
		}
	}
</script>

<title>Transplants vs Zombies</title>

<head>
	<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" />
</head>

<main id="results-body">
	<h1>
		<img
			style="border: none; background-color:0; padding:0;"
			itemtype="https://schema.org/ImageObject"
			src="https://californiatransplants.com/wp-content/uploads/2020/02/118272348.png"
			width="303"
			height="150"
			alt="California Transplant"
			id="test_image"
		/>
	</h1>
	<form on:submit={handleFormSubmit}>
		<input
			type="file"
			id="file-input"
			name="file"
			style="display:none"
			on:change={handleFileInputChange}
		/>
		<button
			type="button"
			class="upload"
			on:click={() => document.getElementById('file-input').click()}
			disabled={isUploading}
		>
			{#if isUploading}
				<div>Uploading... Please wait</div>
			{:else}
				Upload
			{/if}
		</button>
		{#if error}
			<p style="color: white;">{error}</p>
		{:else if resultData}
			<hr />
			<div
				style="max-width: 90%; margin: 0 auto; background-color: #f7f7f7; padding: 2%; border-radius: 2%;"
			>
				<h2>Results - {resultData.filename}</h2>
				<button class="saveToCSV" on:click={saveToCSV}>Save to CSV</button>
				<hr style="border: 1px solid #ddd;" />
				<p>
					<strong style="color: black;">Single Plants Count:</strong>
					<span style="color: green;">{resultData.info.single_plants_count}</span>
				</p>
				<p>
					<strong style="color: black;">Multiple Plants Count:</strong>
					<span style="color: green;">{resultData.info.multiple_plants_count}</span>
				</p>
				<p>
					<strong style="color: black;">No Plants Count:</strong>
					<span style="color: green;">{resultData.info.no_plants_count}</span>
				</p>
				<p>
					<strong style="color: black;">Viability:</strong>
					<span style="color: green;"
						>{(
							((resultData.info.single_plants_count + resultData.info.multiple_plants_count * 2) /
								(resultData.info.num_rows * resultData.info.num_cols)) *
							100
						).toFixed(2)}%</span
					>
				</p>
				<p>
					<strong style="color: black;">Tray Rows:</strong>
					<span style="color: green;">{resultData.info.num_rows}</span>
				</p>
				<p>
					<strong style="color: black;">Tray Columns:</strong>
					<span style="color: green;">{resultData.info.num_cols}</span>
				</p>
				<p>
					<strong style="color: black;">Tray Cell Count:</strong>
					<span style="color: green;">{resultData.info.num_rows * resultData.info.num_cols}</span>
				</p>
				<h3>Result Matrix:</h3>
				<table style="margin: 0 auto; border-collapse: collapse; text-align: center;">
					{#each resultData.info.result_matrix as row}
						<tr>
							{#each row as cell}
								<td
									style="border: 1px solid black; opacity: 1; padding: 5px; {cell == 1
										? 'color: green;'
										: cell == 2
										? 'color: blue;'
										: 'color: red;'}">{cell}</td
								>
							{/each}
						</tr>
					{/each}
				</table>
			</div>
			<h3 style="color:white;">Original Image</h3>
			<hr style="border: 1px solid #ddd;" />
			<div style="text-align: center;">
				<Magnifier src="data:image/png;base64, {resultData.original_image}" />
			</div>
			<h3 style="color:white;">Gridded Image</h3>
			<hr style="border: 1px solid #ddd;" />
			<div style="text-align: center;">
				<Magnifier src="data:image/png;base64, {resultData.grid_image}" />
			</div>
			<h3 style="color:white;">Result Image</h3>
			<hr style="border: 1px solid #ddd;" />
			<div style="text-align: center;">
				<Magnifier src="data:image/png;base64, {resultData.result_image}" />
			</div>
		{/if}
	</form>
</main>

<style>
	button.upload {
		margin-top: 7px;
		display: flex;
		align-items: center;
		justify-content: center;
		background-color: #2b5622;
		color: white;
		border-radius: 4px;
		border: none;
		padding: 8px 16px;
		cursor: pointer;
		transition: background-color 0.2s ease-in-out;
	}

	button.upload:disabled {
		opacity: 0.8;
		cursor: not-allowed;
	}

	button.upload:hover:not(:disabled) {
		background-color: #a9997f;
	}

	button.saveToCSV {
		display: flex;
		align-items: center;
		justify-content: center;
		background-color: green;
		color: white;
		border-radius: 4px;
		border: none;
		padding: 8px 16px;
		cursor: pointer;
		transition: background-color 0.2s ease-in-out;
	}

	:global(body) {
		background-image: url('https://californiatransplants.com/wp-content/uploads/2020/03/about-general-bg.jpg');
		/* background-image: url('https://californiatransplants.com/wp-content/uploads/2020/06/heroJune-1024x396.jpg'); */
		/* background-size: cover; */
		/* background-repeat: no-repeat; */
		/* background-position-y: -35%; */
		/* background-position-x: calc(-70px + 0vw); */
	}

	main {
		font-family: 'Montserrat';
		font-weight: lighter;
		display: flex;
		flex-direction: column;
		align-items: center;
		margin-left: -29px;
		margin-right: -8px;
		margin-bottom: -10px;
	}

	h1 {
		margin-top: -20px;
		margin-bottom: -60px;
		width: 100%;
		height: 250px;
		background-image: url('https://californiatransplants.com/wp-content/uploads/2020/02/home-hero-1024x611.jpg');
		background-size: cover;
		background-position: center center;
		background-position-y: 25%;
	}

	form {
		display: flex;
		flex-direction: column;
		align-items: center;
		margin-left: 10%;
		margin-right: 10%;
	}

	label {
		font-weight: bold;
		margin-bottom: 10px;
	}

	input[type='file'] {
		margin-bottom: 10px;
	}

	button[type='submit'] {
		margin-top: 10px;
	}

	p {
		font-size: large;
		font-weight: bold;
	}

	hr {
		width: 100%;
		border: 1px solid black;
		margin: 20px 0;
	}

	h2 {
		margin-top: 50px;
		font-size: xx-large;
		margin-bottom: 10px;
	}

	h3 {
		font-size: x-large;
	}

	table {
		margin-bottom: 20px;
		opacity: 0.8;
		background-color: #e2ddd7;
	}

	table td {
		border: 1px solid black;
		opacity: 1;
		padding: 5px;
	}

	img {
		display: block;
		margin: 20px auto;
		max-width: 100%;
		border: 6px solid #7a7e2f;
	}
</style>
